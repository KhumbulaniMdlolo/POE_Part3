﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

// General Information about an assembly is controlled through the following
// A collection of attributes. Modify the information by changing the attribute values.
// Associated with an assembly.
[assembly: AssemblyTitle("POE")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("POE")]
[assembly: AssemblyCopyright("Copyright ©  2023")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// When ComVisible is set to false, the types in this assembly are hidden.
// COM components.  If you need to access a type in this assembly
// COM. set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// In order to begin building localizable applications, set
// <UICulture>CultureYouAreCodingWith</UICulture> in your .csproj file inside a <PropertyGroup>.
// Set the UICulture> to en-US, for example, if you use US English in your source files.
// Then remove the comment from the NeutralResourceLanguage property below.
// Change the "en-US" to match the UICulture setting in the project file.
//[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]


[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, //The location of where the theme-specific resource dictionaries are.
                                     //(Used if a resource on the page cannot be found,
                                      // or resource dictionaries for applications)
    ResourceDictionaryLocation.SourceAssembly //The location of the generic resource dictionary
                                              //(Used if a resource on the page cannot be found,
                                              // app, or any resource dictionary based on a specific theme)
)]


// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
